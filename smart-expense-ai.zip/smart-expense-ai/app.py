import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from predict import predict_category
from utils import monthly_summary, predict_next_month

st.set_page_config(page_title="Smart Expense AI Tracker")

st.title("💰 Smart Expense AI Tracker")

st.markdown("Upload your expense file (CSV or Excel)")

# ---------------- FILE UPLOAD ---------------- #

uploaded_file = st.file_uploader(
    "Upload your expense file",
    type=["csv", "xlsx"]
)

if uploaded_file:

    try:
        # Detect file type automatically
        if uploaded_file.name.endswith(".csv"):
            df = pd.read_csv(uploaded_file)
        elif uploaded_file.name.endswith(".xlsx"):
            df = pd.read_excel(uploaded_file, engine="openpyxl")
        else:
            st.error("Unsupported file type!")
            st.stop()

        # ---------------- COLUMN VALIDATION ---------------- #
        required_columns = ["date", "description", "amount", "category"]

        if not all(col in df.columns for col in required_columns):
            st.error("File must contain columns: date, description, amount, category")
            st.stop()

        # ---------------- DATA CLEANING ---------------- #
        df["date"] = pd.to_datetime(df["date"], errors="coerce")
        df["amount"] = pd.to_numeric(df["amount"], errors="coerce")

        df = df.dropna()

        # ---------------- SHOW DATA ---------------- #
        st.subheader("📊 Raw Data")
        st.dataframe(df)

        # ---------------- TOTAL EXPENSE ---------------- #
        total = df["amount"].sum()
        st.success(f"Total Expense: ₹ {round(total, 2)}")

        # ---------------- CATEGORY PIE CHART ---------------- #
        st.subheader("📂 Category Distribution")

        category_sum = df.groupby("category")["amount"].sum()

        fig1, ax1 = plt.subplots()
        ax1.pie(category_sum, labels=category_sum.index, autopct="%1.1f%%")
        ax1.set_title("Expense by Category")
        st.pyplot(fig1)

        # ---------------- MONTHLY SUMMARY ---------------- #
        st.subheader("📅 Monthly Spending")

        monthly = monthly_summary(df)

        fig2, ax2 = plt.subplots()
        ax2.bar(monthly.index, monthly.values)
        ax2.set_xlabel("Month")
        ax2.set_ylabel("Total Expense")
        ax2.set_title("Monthly Expense")
        st.pyplot(fig2)

        # ---------------- PREDICTION ---------------- #
        st.subheader("📈 Next Month Prediction")

        prediction = predict_next_month(df)
        st.info(f"Estimated Next Month Expense: ₹ {prediction}")

    except Exception as e:
        st.error(f"Error processing file: {e}")


# ---------------- MANUAL CATEGORY PREDICTION ---------------- #

st.subheader("🤖 Predict Expense Category")

desc = st.text_input("Enter Expense Description")

if st.button("Predict Category"):
    if desc:
        try:
            category = predict_category(desc)
            st.success(f"Predicted Category: {category}")
        except Exception as e:
            st.error(f"Model not trained or error occurred: {e}")
    else:
        st.warning("Please enter a description.")
