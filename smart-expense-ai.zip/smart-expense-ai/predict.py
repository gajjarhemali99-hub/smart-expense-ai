import joblib

model = joblib.load("models/category_model.pkl")
vectorizer = joblib.load("models/vectorizer.pkl")

def predict_category(description):
    text_vector = vectorizer.transform([description])
    prediction = model.predict(text_vector)
    return prediction[0]
