import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression

def monthly_summary(df):
    df["date"] = pd.to_datetime(df["date"])
    monthly = df.groupby(df["date"].dt.month)["amount"].sum()
    return monthly

def predict_next_month(df):
    df["date"] = pd.to_datetime(df["date"])
    monthly = df.groupby(df["date"].dt.month)["amount"].sum()

    X = np.array(monthly.index).reshape(-1, 1)
    y = monthly.values

    model = LinearRegression()
    model.fit(X, y)

    next_month = max(monthly.index) + 1
    prediction = model.predict([[next_month]])

    return round(prediction[0], 2)
